using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ApplicationMessage.Views.Messages
{
    public class RoomChatModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
