using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ApplicationMessage.Views.Account
{
    public class _ProfileFormPartialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
