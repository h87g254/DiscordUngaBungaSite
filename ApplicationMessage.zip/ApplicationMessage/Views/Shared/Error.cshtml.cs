using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ApplicationMessage.Views.Shared
{
    public class ErrorModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
