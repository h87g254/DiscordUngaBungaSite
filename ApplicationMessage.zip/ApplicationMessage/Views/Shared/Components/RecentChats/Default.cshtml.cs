using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ApplicationMessage.Views.Components.RecentChats
{
    public class DefaultModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
