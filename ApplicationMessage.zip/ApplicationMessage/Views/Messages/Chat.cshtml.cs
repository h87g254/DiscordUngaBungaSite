using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ApplicationMessage.Views.Messages
{
    public class ChatModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
