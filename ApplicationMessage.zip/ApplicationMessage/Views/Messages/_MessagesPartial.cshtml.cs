using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ApplicationMessage.Views.Messages
{
    public class _MessagesPartialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
