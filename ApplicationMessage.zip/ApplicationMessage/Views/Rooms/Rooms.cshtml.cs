using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ApplicationMessage.Views.Rooms
{
    public class RoomsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
